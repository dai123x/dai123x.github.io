/**
 * pages/data/data.js — 数据与快照中心
 */

import { store } from '../../utils/store.js';

Page({
  data: {
    classesCount: 0,
    studentsCount: 0,
    fivesCount: 0,
    subjectsCount: 0,
    dailyCount: 0,
    snapshots: [],
  },

  onShow() {
    this.loadDataInfo();
  },

  loadDataInfo() {
    const snap = store.snapshot();
    const snapshots = store.listSnapshots();

    let dCount = 0;
    Object.values(snap.daily || {}).forEach((d) => {
      dCount += (d.entries || []).length;
    });

    this.setData({
      classesCount: snap.classes.length,
      studentsCount: snap.students.length,
      fivesCount: Object.keys(snap.fives || {}).length,
      subjectsCount: Object.keys(snap.subjects || {}).length,
      dailyCount: dCount,
      snapshots,
    });
  },

  createSnapshot() {
    const snap = store.createSnapshot();
    this.loadDataInfo();
    wx.showToast({ title: '快照存档创建成功', icon: 'success' });
  },

  restoreSnapshot(e) {
    const sid = e.currentTarget.dataset.id;
    const snap = this.data.snapshots.find((s) => s.id === sid);
    if (!snap) return;

    wx.showModal({
      title: '确认恢复历史快照',
      content: `确定要恢复到【${snap.name}】(${snap.time}) 吗？当前未保存的修改将被覆盖。`,
      success: (res) => {
        if (res.confirm) {
          const ok = store.restoreSnapshot(sid);
          if (ok) {
            this.loadDataInfo();
            wx.showToast({ title: '已成功还原至快照', icon: 'success' });
          }
        }
      }
    });
  },

  deleteSnapshot(e) {
    const sid = e.currentTarget.dataset.id;
    store.deleteSnapshot(sid);
    this.loadDataInfo();
    wx.showToast({ title: '快照已删除', icon: 'none' });
  },

  loadDemo() {
    wx.showModal({
      title: '载入初二(3)班演示数据',
      content: '载入演示数据将清空当前所有本地数据，并生成12位学生全套真实评分。继续？',
      success: (res) => {
        if (res.confirm) {
          store.loadDemo();
          this.loadDataInfo();
          wx.showToast({ title: '演示数据已重新载入', icon: 'success' });
        }
      }
    });
  },

  resetAllData() {
    wx.showModal({
      title: '高危操作：清空所有数据',
      content: '确定要彻底清空本设备上的所有班级、学生档案与评分流水吗？此操作无法撤销。',
      confirmColor: '#ef4444',
      success: (res) => {
        if (res.confirm) {
          store.restore({ classes: [], students: [], fives: {}, subjects: {}, daily: {}, config: {} });
          this.loadDataInfo();
          wx.showToast({ title: '数据已全部清空', icon: 'none' });
        }
      }
    });
  },

  copyBackupJson() {
    const json = JSON.stringify(store.snapshot(), null, 2);
    wx.setClipboardData({
      data: json,
      success() {
        wx.showToast({ title: 'JSON 备份数据已复制', icon: 'success' });
      }
    });
  }
});
