/**
 * pages/matrix/matrix.js — 全班成绩总览大表
 */

import { store, SOURCES } from '../../utils/store.js';
import { evaluateAll, rankBy, SCORE_OF, isNum, fmt1, gradeOf, gradeColor } from '../../utils/score.js';

const app = getApp();

Page({
  data: {
    className: '',
    studentsCount: 0,
    searchQuery: '',
    filter: 'all', // 'all' | 'exc' | 'good' | 'pass' | 'fail'
    sortKey: 'rank',
    sortAsc: true,
    rows: [],
    rawRows: [],
    // 汇总指标
    summaryAvg: '—',
    summaryMax: '—',
    summaryMin: '—',
    summaryPass: '0.0%',
  },

  onShow() {
    this.loadMatrix();
  },

  onPullDownRefresh() {
    this.loadMatrix();
    wx.stopPullDownRefresh();
  },

  loadMatrix() {
    const curCls = app.getCurrentClass();
    if (!curCls) return;

    const students = store.listStudents(curCls.id);
    const cfg = store.getConfig();

    const bundles = students.map((stu) => ({
      studentId: stu.id,
      fives: store.getFives(stu.id, SOURCES.TEACHER),
      subjects: store.getSubjects(stu.id, SOURCES.TEACHER),
      daily: store.getDaily(stu.id, SOURCES.TEACHER),
    }));

    const results = evaluateAll(bundles, cfg);
    const { rankMap } = rankBy(results, SCORE_OF.composite);

    const rawRows = students.map((stu) => {
      const ev = results.find((r) => r.studentId === stu.id);
      const f = ev && ev.fives ? ev.fives.fives : {};
      const comp = ev && ev.composite ? ev.composite.score : null;
      return {
        id: stu.id,
        no: stu.no || '',
        name: stu.name || '',
        rank: rankMap.get(stu.id) || 999,
        composite: comp,
        grade: gradeOf(comp),
        compColor: gradeColor(comp),
        de: f.de ?? null,
        zhi: f.zhi ?? null,
        ti: f.ti ?? null,
        mei: f.mei ?? null,
        lao: f.lao ?? null,
        subject: ev && ev.subject ? ev.subject.score : null,
        daily: ev && ev.daily ? ev.daily.score : null,
      };
    });

    this.setData({
      className: curCls.name,
      studentsCount: students.length,
      rawRows,
    });

    this.applyFilterAndSort();
  },

  onSearchInput(e) {
    this.setData({ searchQuery: e.detail.value.trim() });
    this.applyFilterAndSort();
  },

  setFilter(e) {
    const filter = e.currentTarget.dataset.filter;
    this.setData({ filter });
    this.applyFilterAndSort();
    wx.vibrateShort && wx.vibrateShort({ type: 'light' });
  },

  setSort(e) {
    const key = e.currentTarget.dataset.key;
    let asc = this.data.sortAsc;
    if (this.data.sortKey === key) {
      asc = !asc;
    } else {
      asc = key === 'rank' || key === 'no';
    }
    this.setData({ sortKey: key, sortAsc: asc });
    this.applyFilterAndSort();
  },

  applyFilterAndSort() {
    let list = this.data.rawRows.slice();

    // 搜索
    const q = this.data.searchQuery.toLowerCase();
    if (q) {
      list = list.filter((r) => r.name.toLowerCase().includes(q) || r.no.toLowerCase().includes(q));
    }

    // 分段
    const f = this.data.filter;
    if (f === 'exc') list = list.filter((r) => isNum(r.composite) && r.composite >= 85);
    else if (f === 'good') list = list.filter((r) => isNum(r.composite) && r.composite >= 75 && r.composite < 85);
    else if (f === 'pass') list = list.filter((r) => isNum(r.composite) && r.composite >= 60 && r.composite < 75);
    else if (f === 'fail') list = list.filter((r) => isNum(r.composite) && r.composite < 60);

    // 排序
    const sk = this.data.sortKey;
    const asc = this.data.sortAsc;
    list.sort((a, b) => {
      let va = a[sk];
      let vb = b[sk];
      if (va == null) va = asc ? 999999 : -999999;
      if (vb == null) vb = asc ? 999999 : -999999;
      if (typeof va === 'string') return asc ? va.localeCompare(vb) : vb.localeCompare(va);
      return asc ? (va - vb) : (vb - va);
    });

    // 计算汇总
    const compScores = list.map((r) => r.composite).filter(isNum);
    const n = compScores.length;
    const avg = n ? compScores.reduce((a, b) => a + b, 0) / n : null;
    const max = n ? Math.max(...compScores) : null;
    const min = n ? Math.min(...compScores) : null;
    const passCount = compScores.filter((s) => s >= 60).length;
    const passRate = n ? ((passCount / n) * 100).toFixed(1) + '%' : '0.0%';

    this.setData({
      rows: list,
      summaryAvg: fmt1(avg),
      summaryMax: fmt1(max),
      summaryMin: fmt1(min),
      summaryPass: passRate,
    });
  },

  viewStudent(e) {
    const sid = e.currentTarget.dataset.id;
    app.globalData.currentStudentId = sid;
    wx.switchTab({ url: '/pages/report/report' });
  },

  copyTableText() {
    const lines = this.data.rows.map((r) =>
      `排名${r.rank <= 900 ? r.rank : '—'}\t学号${r.no}\t${r.name}\t${fmt1(r.composite)}分\t${r.grade.grade}`
    );
    const text = `${this.data.className} 成绩总览\n` + lines.join('\n');
    wx.setClipboardData({
      data: text,
      success() {
        wx.showToast({ title: '成绩汇总已复制剪贴板', icon: 'success' });
      }
    });
  }
});
