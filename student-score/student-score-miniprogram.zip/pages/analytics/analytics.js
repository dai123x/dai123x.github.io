/**
 * pages/analytics/analytics.js — 学情与教学质量深度诊断大屏
 */

import { store, SOURCES } from '../../utils/store.js';
import { FIVES, SUBJECTS } from '../../utils/model.js';
import { evaluateAll, rankBy, SCORE_OF, isNum, fmt1, gradeColor } from '../../utils/score.js';

const app = getApp();

Page({
  data: {
    className: '',
    totalStudents: 0,
    gradedCount: 0,
    avgScore: '—',
    countExc: 0,
    countGood: 0,
    countPass: 0,
    countFail: 0,
    pctExc: '0.0',
    pctGood: '0.0',
    pctPass: '0.0',
    pctFail: '0.0',
    fivesAvgs: [],
    subjectAvgs: [],
    honorsList: [],
    warningStudents: [],
  },

  onShow() {
    this.loadAnalytics();
  },

  onPullDownRefresh() {
    this.loadAnalytics();
    wx.stopPullDownRefresh();
  },

  loadAnalytics() {
    const curCls = app.getCurrentClass();
    if (!curCls) return;

    const students = store.listStudents(curCls.id);
    const cfg = store.getConfig();

    const bundles = students.map((stu) => ({
      studentId: stu.id,
      fives: store.getFives(stu.id, SOURCES.TEACHER),
      subjects: store.getSubjects(stu.id, SOURCES.TEACHER),
      daily: store.getDaily(stu.id, SOURCES.TEACHER),
    }));

    const results = evaluateAll(bundles, cfg);
    const validResults = results.filter((r) => isNum(r.composite && r.composite.score));
    const compScores = validResults.map((r) => r.composite.score);

    const total = students.length;
    const n = compScores.length;
    const avgTotal = n ? compScores.reduce((a, b) => a + b, 0) / n : null;

    const countExc = compScores.filter((s) => s >= 85).length;
    const countGood = compScores.filter((s) => s >= 75 && s < 85).length;
    const countPass = compScores.filter((s) => s >= 60 && s < 75).length;
    const countFail = compScores.filter((s) => s < 60).length;

    const pct = (cnt) => (n > 0 ? ((cnt / n) * 100).toFixed(1) : '0.0');

    // 五育均分
    const fivesAvgs = FIVES.map((f) => {
      const vals = validResults.map((r) => r.fives && r.fives.fives ? r.fives.fives[f.key] : null).filter(isNum);
      const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      return {
        key: f.key,
        name: f.name,
        color: f.color,
        avg: fmt1(avg),
        pct: Math.min(100, Math.round(avg)),
      };
    });

    // 13 门学科均分排行榜
    const subjectAvgs = SUBJECTS.map((s) => {
      const vals = validResults.map((r) => r.subject && r.subject.subjects ? r.subject.subjects[s.key] : null).filter(isNum);
      const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      return {
        key: s.key,
        name: s.name,
        avgVal: avg,
        avg: fmt1(avg),
        pct: Math.max(0, Math.min(100, Math.round(avg))),
        color: gradeColor(avg),
      };
    }).sort((a, b) => b.avgVal - a.avgVal);

    // 五育标杆之星
    const getTop = (dimKey) => {
      let topStu = null, topScore = -1;
      validResults.forEach((r) => {
        const s = r.fives && r.fives.fives ? r.fives.fives[dimKey] : null;
        if (isNum(s) && s > topScore) {
          topScore = s;
          topStu = students.find((x) => x.id === r.studentId);
        }
      });
      return { stu: topStu ? topStu.name : '暂无', score: fmt1(topScore) };
    };

    const honorsList = [
      { title: '德育标杆', ico: '🌟', color: '#f2545b', ...getTop('de') },
      { title: '智育标杆', ico: '💡', color: '#3d7bfd', ...getTop('zhi') },
      { title: '体育健将', ico: '🏃', color: '#16a97e', ...getTop('ti') },
      { title: '美育新星', ico: '🎨', color: '#a355e8', ...getTop('mei') },
      { title: '劳动模范', ico: '🌱', color: '#e08a1e', ...getTop('lao') },
    ];

    // 学情预警名单
    const warningStudents = [];
    validResults.forEach((r) => {
      const stu = students.find((s) => s.id === r.studentId);
      if (!stu) return;

      const lowSubs = [];
      if (r.subject && r.subject.subjects) {
        for (const [k, v] of Object.entries(r.subject.subjects)) {
          if (isNum(v) && v < 60) {
            const sObj = SUBJECTS.find((sub) => sub.key === k);
            lowSubs.push(`${sObj ? sObj.name : k} (${fmt1(v)}分)`);
          }
        }
      }

      const isDailyLow = isNum(r.daily && r.daily.score) && r.daily.score < 90;
      if (lowSubs.length || isDailyLow) {
        warningStudents.push({
          id: stu.id,
          name: stu.name,
          no: stu.no,
          compScore: fmt1(r.composite.score),
          lowSubs,
          dailyLow: isDailyLow ? `${fmt1(r.daily.score)}分` : null,
        });
      }
    });

    this.setData({
      className: curCls.name,
      totalStudents: total,
      gradedCount: n,
      avgScore: fmt1(avgTotal),
      countExc,
      countGood,
      countPass,
      countFail,
      pctExc: pct(countExc),
      pctGood: pct(countGood),
      pctPass: pct(countPass),
      pctFail: pct(countFail),
      fivesAvgs,
      subjectAvgs,
      honorsList,
      warningStudents,
    });
  },

  goToGradeStudent(e) {
    const sid = e.currentTarget.dataset.id;
    app.globalData.currentStudentId = sid;
    wx.switchTab({ url: '/pages/grade/grade' });
  }
});
