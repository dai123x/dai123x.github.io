/**
 * pages/roster/roster.js — 班级与学生名册管理
 */

import { store } from '../../utils/store.js';

const app = getApp();

Page({
  data: {
    classes: [],
    classIndex: 0,
    currentClass: null,
    students: [],
    newStudentNo: '',
    newStudentName: '',
    newStudentGender: '男',
    showAddClassModal: false,
    newClassName: '',
    newClassGrade: '八年级',
    newClassTerm: '2026学年第一学期',
  },

  onShow() {
    this.loadRoster();
  },

  loadRoster() {
    const classes = store.listClasses();
    if (!classes.length) {
      this.setData({ classes: [], currentClass: null, students: [] });
      return;
    }

    let curCls = app.getCurrentClass();
    let idx = classes.findIndex((c) => c.id === (curCls ? curCls.id : ''));
    if (idx === -1) {
      idx = 0;
      curCls = classes[0];
      app.setCurrentClassId(curCls.id);
    }

    const students = store.listStudents(curCls.id);
    this.setData({
      classes,
      classIndex: idx,
      currentClass: curCls,
      students,
    });
  },

  onClassChange(e) {
    const idx = Number(e.detail.value);
    const cls = this.data.classes[idx];
    if (cls) {
      app.setCurrentClassId(cls.id);
      this.setData({ classIndex: idx, currentClass: cls });
      this.loadRoster();
    }
  },

  openAddClass() {
    this.setData({
      showAddClassModal: true,
      newClassName: '',
      newClassGrade: '八年级',
      newClassTerm: '2026学年第一学期',
    });
  },

  closeAddClass() {
    this.setData({ showAddClassModal: false });
  },

  onClassNameInput(e) { this.setData({ newClassName: e.detail.value }); },
  onClassGradeInput(e) { this.setData({ newClassGrade: e.detail.value }); },
  onClassTermInput(e) { this.setData({ newClassTerm: e.detail.value }); },

  submitAddClass() {
    const name = this.data.newClassName.trim();
    if (!name) {
      wx.showToast({ title: '请输入班级名称', icon: 'none' });
      return;
    }

    const cls = store.createClass({
      name,
      grade: this.data.newClassGrade.trim(),
      term: this.data.newClassTerm.trim(),
    });

    app.setCurrentClassId(cls.id);
    this.setData({ showAddClassModal: false });
    this.loadRoster();
    wx.showToast({ title: `已创建班级【${cls.name}】`, icon: 'success' });
  },

  onNoInput(e) { this.setData({ newStudentNo: e.detail.value }); },
  onNameInput(e) { this.setData({ newStudentName: e.detail.value }); },
  onGenderChange(e) { this.setData({ newStudentGender: e.detail.value }); },

  addStudent() {
    const name = this.data.newStudentName.trim();
    const no = this.data.newStudentNo.trim();
    if (!name) {
      wx.showToast({ title: '请输入学生姓名', icon: 'none' });
      return;
    }
    if (!this.data.currentClass) {
      wx.showToast({ title: '请先创建班级', icon: 'none' });
      return;
    }

    store.upsertStudent({
      classId: this.data.currentClass.id,
      name,
      no: no || String(this.data.students.length + 1).padStart(2, '0'),
      gender: this.data.newStudentGender,
    });

    this.setData({
      newStudentNo: '',
      newStudentName: '',
    });
    this.loadRoster();
    wx.showToast({ title: `学生 ${name} 建档成功`, icon: 'success' });
  },

  deleteStudent(e) {
    const sid = e.currentTarget.dataset.id;
    const stu = this.data.students.find((s) => s.id === sid);
    if (!stu) return;

    wx.showModal({
      title: '确认删除学生',
      content: `确定要删除学生【${stu.name}】及其所有评分记录吗？`,
      success: (res) => {
        if (res.confirm) {
          store.removeStudent(sid);
          this.loadRoster();
          wx.showToast({ title: '已删除学生', icon: 'none' });
        }
      }
    });
  },

  loadDemoData() {
    wx.showModal({
      title: '重新载入演示数据',
      content: '载入演示数据将清空当前所有数据并导入初二(3)班示例。继续？',
      success: (res) => {
        if (res.confirm) {
          store.loadDemo();
          const cls = store.listClasses()[0];
          app.setCurrentClassId(cls ? cls.id : null);
          this.loadRoster();
          wx.showToast({ title: '演示数据已载入', icon: 'success' });
        }
      }
    });
  }
});
