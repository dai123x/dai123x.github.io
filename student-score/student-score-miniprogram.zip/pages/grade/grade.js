/**
 * pages/grade/grade.js — 智能打分工作台
 */

import { store, SOURCES } from '../../utils/store.js';
import { FIVES, SUBJECTS, DEFAULT_DAILY_ITEMS, emptyFives, emptySubjects } from '../../utils/model.js';
import { termOf, isNum, fmt1 } from '../../utils/score.js';

const app = getApp();

Page({
  data: {
    students: [],
    selectedStudentId: null,
    currentStudent: null,
    tab: 'fives', // 'fives' | 'subject' | 'daily'
    fivesList: [],
    fivesData: {},
    subjectsList: [],
    subjectsData: {},
    dailyEntries: [],
    dailyQuickItems: DEFAULT_DAILY_ITEMS,
    diyLabel: '',
    diyDelta: 1,
    currentTermWeights: { usual: 20, mid: 30, final: 50 },
  },

  onShow() {
    this.initData();
  },

  initData() {
    const curCls = app.getCurrentClass();
    if (!curCls) return;

    const students = store.listStudents(curCls.id);
    if (!students.length) {
      this.setData({ students: [], selectedStudentId: null, currentStudent: null });
      return;
    }

    let sid = app.globalData.currentStudentId;
    if (!sid || !students.some((s) => s.id === sid)) {
      sid = students[0].id;
      app.globalData.currentStudentId = sid;
    }

    const curStu = students.find((s) => s.id === sid);
    const cfg = store.getConfig();

    this.setData({
      students,
      selectedStudentId: sid,
      currentStudent: curStu,
      fivesList: FIVES,
      subjectsList: SUBJECTS,
      currentTermWeights: cfg.termWeights || { usual: 20, mid: 30, final: 50 },
    });

    this.loadStudentScore(sid);
  },

  loadStudentScore(sid) {
    if (!sid) return;

    // 1. 五育
    let fRec = store.getFives(sid, SOURCES.TEACHER);
    if (!fRec) fRec = emptyFives();

    // 2. 学科
    let sRec = store.getSubjects(sid, SOURCES.TEACHER);
    if (!sRec) sRec = emptySubjects();

    // 3. 日常流水
    const dRec = store.getDaily(sid, SOURCES.TEACHER);

    this.setData({
      fivesData: fRec,
      subjectsData: sRec,
      dailyEntries: dRec || [],
    });
  },

  selectStudent(e) {
    const sid = e.currentTarget.dataset.id;
    if (sid === this.data.selectedStudentId) return;

    app.globalData.currentStudentId = sid;
    const curStu = this.data.students.find((s) => s.id === sid);

    this.setData({
      selectedStudentId: sid,
      currentStudent: curStu,
    });
    this.loadStudentScore(sid);
    wx.vibrateShort && wx.vibrateShort({ type: 'light' });
  },

  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ tab });
  },

  // 五育打分输入
  onFivesInput(e) {
    const { dim, item } = e.currentTarget.dataset;
    let val = e.detail.value.trim();
    let num = val === '' ? null : Number(val);
    if (num !== null) {
      num = Math.max(0, Math.min(100, Math.round(num)));
    }

    const fData = this.data.fivesData;
    if (!fData[dim]) fData[dim] = {};
    fData[dim][item] = num;

    this.setData({ fivesData: fData });
    store.setFives(this.data.selectedStudentId, SOURCES.TEACHER, fData);
  },

  // 步进调节
  stepFives(e) {
    const { dim, item, step } = e.currentTarget.dataset;
    const fData = this.data.fivesData;
    let cur = (fData[dim] && isNum(fData[dim][item])) ? fData[dim][item] : 80;
    cur = Math.max(0, Math.min(100, cur + Number(step)));

    if (!fData[dim]) fData[dim] = {};
    fData[dim][item] = cur;

    this.setData({ fivesData: fData });
    store.setFives(this.data.selectedStudentId, SOURCES.TEACHER, fData);
    wx.vibrateShort && wx.vibrateShort({ type: 'light' });
  },

  // 某育一键填分
  fillDim(e) {
    const { dim, val } = e.currentTarget.dataset;
    const scoreVal = Number(val);
    const fData = this.data.fivesData;
    const dimObj = FIVES.find((f) => f.key === dim);
    if (!dimObj) return;

    if (!fData[dim]) fData[dim] = {};
    dimObj.items.forEach((it) => {
      fData[dim][it.key] = scoreVal;
    });

    this.setData({ fivesData: fData });
    store.setFives(this.data.selectedStudentId, SOURCES.TEACHER, fData);
    wx.showToast({ title: `${dimObj.name}育全部填入 ${val} 分`, icon: 'none' });
  },

  clearDim(e) {
    const { dim } = e.currentTarget.dataset;
    const fData = this.data.fivesData;
    const dimObj = FIVES.find((f) => f.key === dim);
    if (!dimObj) return;

    if (!fData[dim]) fData[dim] = {};
    dimObj.items.forEach((it) => {
      fData[dim][it.key] = null;
    });

    this.setData({ fivesData: fData });
    store.setFives(this.data.selectedStudentId, SOURCES.TEACHER, fData);
    wx.showToast({ title: `${dimObj.name}育已清空`, icon: 'none' });
  },

  // 学科成绩输入
  onSubjInput(e) {
    const { subj, part } = e.currentTarget.dataset;
    let val = e.detail.value.trim();
    let num = val === '' ? null : Number(val);
    if (num !== null) {
      num = Math.max(0, Math.min(100, Math.round(num)));
    }

    const sData = this.data.subjectsData;
    if (!sData[subj]) sData[subj] = { usual: null, mid: null, final: null };
    sData[subj][part] = num;

    this.setData({ subjectsData: sData });
    store.setSubjects(this.data.selectedStudentId, SOURCES.TEACHER, sData);
  },

  // 快捷添加日常表现
  addQuickDaily(e) {
    const it = e.currentTarget.dataset.item;
    const sid = this.data.selectedStudentId;
    store.addDailyEntry(sid, SOURCES.TEACHER, {
      key: it.key,
      label: it.label,
      delta: it.delta,
    });
    this.setData({ dailyEntries: store.getDaily(sid, SOURCES.TEACHER) });
    wx.showToast({ title: `${it.delta > 0 ? '+' : ''}${it.delta} 分记录成功`, icon: 'none' });
    wx.vibrateShort && wx.vibrateShort({ type: 'light' });
  },

  // 自定义日常表现
  onDiyLabelInput(e) { this.setData({ diyLabel: e.detail.value }); },
  onDiyDeltaChange(e) { this.setData({ diyDelta: Number(e.detail.value) }); },

  submitDiyDaily() {
    const label = this.data.diyLabel.trim();
    if (!label) {
      wx.showToast({ title: '请输入项目描述', icon: 'none' });
      return;
    }
    const sid = this.data.selectedStudentId;
    store.addDailyEntry(sid, SOURCES.TEACHER, {
      key: 'diy_' + Date.now(),
      label,
      delta: this.data.diyDelta,
    });
    this.setData({
      dailyEntries: store.getDaily(sid, SOURCES.TEACHER),
      diyLabel: '',
    });
    wx.showToast({ title: '自定义日常记录成功', icon: 'none' });
  },

  deleteDaily(e) {
    const idx = e.currentTarget.dataset.index;
    const sid = this.data.selectedStudentId;
    store.removeDailyEntry(sid, SOURCES.TEACHER, idx);
    this.setData({ dailyEntries: store.getDaily(sid, SOURCES.TEACHER) });
    wx.showToast({ title: '已移除记录', icon: 'none' });
  }
});
