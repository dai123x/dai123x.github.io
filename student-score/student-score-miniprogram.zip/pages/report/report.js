/**
 * pages/report/report.js — 学生个人综合素质成长档案与荣誉证书
 */

import { store, SOURCES } from '../../utils/store.js';
import { FIVES, SUBJECTS } from '../../utils/model.js';
import { evaluate, evaluateAll, rankBy, SCORE_OF, isNum, fmt1, gradeOf, gradeColor, termOf } from '../../utils/score.js';

const app = getApp();

Page({
  data: {
    students: [],
    studentIndex: 0,
    currentStudent: null,
    className: '',
    compositeScore: '—',
    rank: '—',
    gradeInfo: { grade: '—', label: '未评定', cls: 'grade-none' },
    fivesList: [],
    subjectsList: [],
    dailyScore: 100,
    dailyEntries: [],
    remark: '',
    showCert: true,
  },

  onShow() {
    this.loadReport();
  },

  onPullDownRefresh() {
    this.loadReport();
    wx.stopPullDownRefresh();
  },

  loadReport() {
    const curCls = app.getCurrentClass();
    if (!curCls) return;

    const students = store.listStudents(curCls.id);
    if (!students.length) return;

    let sid = app.globalData.currentStudentId;
    let sIdx = students.findIndex((s) => s.id === sid);
    if (sIdx === -1) {
      sIdx = 0;
      sid = students[0].id;
      app.globalData.currentStudentId = sid;
    }

    const curStu = students[sIdx];
    const cfg = store.getConfig();

    // 计算全班排名
    const bundles = students.map((stu) => ({
      studentId: stu.id,
      fives: store.getFives(stu.id, SOURCES.TEACHER),
      subjects: store.getSubjects(stu.id, SOURCES.TEACHER),
      daily: store.getDaily(stu.id, SOURCES.TEACHER),
    }));

    const allResults = evaluateAll(bundles, cfg);
    const { rankMap } = rankBy(allResults, SCORE_OF.composite);

    // 当前学生评价
    const myBundle = bundles.find((b) => b.studentId === sid);
    const ev = evaluate(myBundle, cfg);
    const compScore = ev.composite.score;
    const rank = rankMap.get(sid) || '—';
    const gradeInfo = gradeOf(compScore);

    // 五育细项
    const fData = ev.fives.fives || {};
    const fivesList = FIVES.map((f) => ({
      key: f.key,
      name: f.name,
      color: f.color,
      score: fmt1(fData[f.key]),
      pct: isNum(fData[f.key]) ? Math.min(100, Math.round(fData[f.key])) : 0,
    }));

    // 学科期末成绩
    const sRec = store.getSubjects(sid, SOURCES.TEACHER) || {};
    const subjectsList = SUBJECTS.map((s) => {
      const sc = sRec[s.key] || {};
      const term = termOf(sc, cfg.termWeights);
      return {
        key: s.key,
        name: s.name,
        usual: fmt1(sc.usual),
        mid: fmt1(sc.mid),
        final: fmt1(sc.final),
        term: fmt1(term),
        color: gradeColor(term),
      };
    });

    // 日常流水
    const dailyEntries = store.getDaily(sid, SOURCES.TEACHER) || [];
    const dailyScore = ev.daily.score;

    // 智能评语
    const savedRemark = wx.getStorageSync('dx_remark_' + sid);
    const remark = savedRemark || this.generateRemark(curStu, ev);

    this.setData({
      students,
      studentIndex: sIdx,
      currentStudent: curStu,
      className: curCls.name,
      compositeScore: fmt1(compScore),
      rank,
      gradeInfo,
      fivesList,
      subjectsList,
      dailyScore: fmt1(dailyScore),
      dailyEntries,
      remark,
    });
  },

  onStudentChange(e) {
    const idx = Number(e.detail.value);
    const stu = this.data.students[idx];
    if (stu) {
      app.globalData.currentStudentId = stu.id;
      this.setData({ studentIndex: idx, currentStudent: stu });
      this.loadReport();
      wx.vibrateShort && wx.vibrateShort({ type: 'light' });
    }
  },

  toggleCert() {
    this.setData({ showCert: !this.data.showCert });
  },

  onRemarkInput(e) {
    const val = e.detail.value;
    this.setData({ remark: val });
    if (this.data.currentStudent) {
      wx.setStorageSync('dx_remark_' + this.data.currentStudent.id, val);
    }
  },

  regenRemark() {
    const curStu = this.data.currentStudent;
    if (!curStu) return;
    const cfg = store.getConfig();
    const ev = evaluate({
      studentId: curStu.id,
      fives: store.getFives(curStu.id, SOURCES.TEACHER),
      subjects: store.getSubjects(curStu.id, SOURCES.TEACHER),
      daily: store.getDaily(curStu.id, SOURCES.TEACHER),
    }, cfg);

    const remark = this.generateRemark(curStu, ev);
    this.setData({ remark });
    wx.setStorageSync('dx_remark_' + curStu.id, remark);
    wx.showToast({ title: '评语建议已刷新', icon: 'none' });
  },

  generateRemark(stu, ev) {
    const f = ev && ev.fives ? ev.fives.fives : {};
    const traits = [];
    if (isNum(f.de) && f.de >= 85) traits.push('遵纪守规、责任心强');
    if (isNum(f.zhi) && f.zhi >= 85) traits.push('求知若渴、勤敏好学');
    if (isNum(f.ti) && f.ti >= 85) traits.push('热爱运动、体魄强健');
    if (isNum(f.mei) && f.mei >= 85) traits.push('具备良好审美艺术修养');
    if (isNum(f.lao) && f.lao >= 85) traits.push('热爱劳动、实践动手扎实');

    const strength = traits.length ? traits.join('，且') : '品行端正、为人谦逊';
    const cScore = ev && ev.composite ? ev.composite.score : 0;
    let levelWord = '各方面均表现优异';
    if (cScore >= 90) levelWord = '表现极其卓越，五育协调并举';
    else if (cScore >= 80) levelWord = '综合素质优良，学业与行为习惯扎实';
    else if (cScore >= 70) levelWord = '表现稳中有升，展现出良好潜质';

    return `【期末综合评语】${stu.name}同学在校${strength}。本学期${levelWord}（综合量化总分 ${fmt1(cScore)} 分，学期等第为 ${gradeOf(cScore).grade}）。望戒骄戒躁，知行合一，笃行致远！`;
  },

  copyRemark() {
    wx.setClipboardData({
      data: this.data.remark,
      success() {
        wx.showToast({ title: '评语已复制剪贴板', icon: 'success' });
      }
    });
  },

  onShareAppMessage() {
    const stu = this.data.currentStudent;
    return {
      title: `${stu ? stu.name : '学生'} · 素质教育成长档案与荣誉证书`,
      path: '/pages/report/report',
    };
  }
});
