/**
 * pages/index/index.js — 工作台主页
 */

import { store, SOURCES } from '../../utils/store.js';
import { evaluateAll, rankBy, SCORE_OF, isNum, fmt1, gradeOf } from '../../utils/score.js';

const app = getApp();

Page({
  data: {
    classes: [],
    classIndex: 0,
    currentClass: null,
    role: 'teacher',
    totalStudents: 0,
    gradedCount: 0,
    avgScore: '—',
    excRate: '0.0',
    passRate: '0.0',
    topStudents: [],
    warningCount: 0,
    countExc: 0,
    countGood: 0,
    countPass: 0,
    countFail: 0,
  },

  onLoad() {
    this.unsubscribe = store.subscribe(() => {
      this.loadDashboardData();
    });
  },

  onShow() {
    this.setData({ role: app.globalData.role || 'teacher' });
    this.loadDashboardData();
  },

  onUnload() {
    if (this.unsubscribe) this.unsubscribe();
  },

  onPullDownRefresh() {
    this.loadDashboardData();
    wx.stopPullDownRefresh();
  },

  loadDashboardData() {
    const classes = store.listClasses();
    if (!classes.length) {
      this.setData({ classes: [], currentClass: null, totalStudents: 0 });
      return;
    }

    let curCls = app.getCurrentClass();
    let idx = classes.findIndex((c) => c.id === (curCls ? curCls.id : ''));
    if (idx === -1) {
      idx = 0;
      curCls = classes[0];
      app.setCurrentClassId(curCls.id);
    }

    const students = store.listStudents(curCls.id);
    const cfg = store.getConfig();

    const bundles = students.map((stu) => ({
      studentId: stu.id,
      fives: store.getFives(stu.id, SOURCES.TEACHER),
      subjects: store.getSubjects(stu.id, SOURCES.TEACHER),
      daily: store.getDaily(stu.id, SOURCES.TEACHER),
    }));

    const results = evaluateAll(bundles, cfg);
    const { ranked } = rankBy(results, SCORE_OF.composite);

    const validScores = ranked.filter((r) => isNum(r.score)).map((r) => r.score);
    const n = validScores.length;
    const avg = n ? validScores.reduce((a, b) => a + b, 0) / n : 0;

    const countExc = validScores.filter((s) => s >= 85).length;
    const countGood = validScores.filter((s) => s >= 75 && s < 85).length;
    const countPass = validScores.filter((s) => s >= 60 && s < 75).length;
    const countFail = validScores.filter((s) => s < 60).length;

    const excRate = n ? ((countExc / n) * 100).toFixed(1) : '0.0';
    const passRate = n ? (((n - countFail) / n) * 100).toFixed(1) : '0.0';

    // 前三名拔尖
    const topStudents = ranked.slice(0, 3).filter((r) => isNum(r.score)).map((r) => {
      const stu = students.find((s) => s.id === r.item.studentId);
      return {
        id: stu ? stu.id : '',
        name: stu ? stu.name : '未知',
        no: stu ? stu.no : '',
        score: fmt1(r.score),
        grade: gradeOf(r.score),
        rank: r.rank,
      };
    });

    this.setData({
      classes,
      classIndex: idx,
      currentClass: curCls,
      totalStudents: students.length,
      gradedCount: n,
      avgScore: fmt1(avg),
      excRate,
      passRate,
      topStudents,
      warningCount: countFail,
      countExc,
      countGood,
      countPass,
      countFail,
    });
  },

  onClassChange(e) {
    const idx = Number(e.detail.value);
    const cls = this.data.classes[idx];
    if (cls) {
      app.setCurrentClassId(cls.id);
      this.setData({ classIndex: idx, currentClass: cls });
      this.loadDashboardData();
      wx.vibrateShort && wx.vibrateShort({ type: 'light' });
    }
  },

  toggleRole() {
    const nextRole = this.data.role === 'teacher' ? 'student' : 'teacher';
    app.globalData.role = nextRole;
    this.setData({ role: nextRole });
    wx.showToast({ title: nextRole === 'teacher' ? '切换为教师管理端' : '切换为学生自查端', icon: 'none' });
  },

  goToGrade() { wx.switchTab({ url: '/pages/grade/grade' }); },
  goToMatrix() { wx.switchTab({ url: '/pages/matrix/matrix' }); },
  goToAnalytics() { wx.switchTab({ url: '/pages/analytics/analytics' }); },
  goToReport() { wx.switchTab({ url: '/pages/report/report' }); },
  goToRoster() { wx.navigateTo({ url: '/pages/roster/roster' }); },
  goToData() { wx.navigateTo({ url: '/pages/data/data' }); },

  onShareAppMessage() {
    const cls = this.data.currentClass;
    return {
      title: `${cls ? cls.name : '学生综合素质评分'} · 学情质量总览`,
      path: '/pages/index/index',
    };
  }
});
