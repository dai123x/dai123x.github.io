/**
 * app.js — 微信小程序入口生命周期
 */

import { store } from './utils/store.js';

App({
  globalData: {
    currentClassId: null,
    currentStudentId: null,
    role: 'teacher', // 'teacher' | 'student'
  },

  onLaunch() {
    console.log('[App] 学生综合素质评分系统启动');
    const classes = store.listClasses();
    if (classes.length) {
      this.globalData.currentClassId = classes[0].id;
      const stus = store.listStudents(classes[0].id);
      if (stus.length) {
        this.globalData.currentStudentId = stus[0].id;
      }
    }
  },

  getCurrentClass() {
    const cid = this.globalData.currentClassId;
    const classes = store.listClasses();
    return classes.find((c) => c.id === cid) || classes[0] || null;
  },

  setCurrentClassId(id) {
    this.globalData.currentClassId = id;
    const stus = store.listStudents(id);
    this.globalData.currentStudentId = stus.length ? stus[0].id : null;
  }
});
