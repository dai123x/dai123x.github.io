/**
 * utils/score.js — 纯计算引擎
 */

import { FIVES, SUBJECTS } from './model.js';

export const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

export function round(v, d = 2) {
  if (!isNum(v)) return null;
  const f = Math.pow(10, d);
  return Math.round((v + Number.EPSILON) * f) / f;
}

export const fmt1 = (v) => (isNum(v) ? round(v, 1).toFixed(1) : '—');

export function weightedMean(pairs) {
  const valid = (pairs || []).filter((p) => isNum(p.value) && isNum(p.weight) && p.weight > 0);
  if (!valid.length) return null;
  const totalW = valid.reduce((acc, p) => acc + p.weight, 0);
  if (totalW <= 0) return null;
  const sum = valid.reduce((acc, p) => acc + p.value * p.weight, 0);
  return sum / totalW;
}

export function termOf(parts, tw) {
  if (!parts) return null;
  return weightedMean([
    { value: parts.usual, weight: tw.usual || 0 },
    { value: parts.mid, weight: tw.mid || 0 },
    { value: parts.final, weight: tw.final || 0 },
  ]);
}

export function evaluateFives(items, fivesWeights) {
  if (!items) return { score: null, fives: {}, available: 0, total: FIVES.length };
  const fives = {};
  for (const f of FIVES) {
    const vals = f.items.map((it) => items[f.key] ? items[f.key][it.key] : null).filter(isNum);
    fives[f.key] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  }
  const pairs = FIVES.map((f) => ({ value: fives[f.key], weight: fivesWeights[f.key] || 0 }));
  const score = weightedMean(pairs);
  const available = Object.values(fives).filter(isNum).length;
  return { score: round(score, 2), fives, available, total: FIVES.length };
}

export function evaluateSubjects(scores, cfg) {
  if (!scores) return { score: null, subjects: {}, available: 0, total: SUBJECTS.length };
  const subjects = {};
  for (const s of SUBJECTS) {
    subjects[s.key] = termOf(scores[s.key], cfg.termWeights);
  }
  const pairs = SUBJECTS.map((s) => ({ value: subjects[s.key], weight: cfg.subjectWeights[s.key] || 0 }));
  const score = weightedMean(pairs);
  const available = Object.values(subjects).filter(isNum).length;
  return { score: round(score, 2), subjects, available, total: SUBJECTS.length };
}

export function dailyScoreOf(entries, cfg) {
  const c = cfg.daily || { base: 100, min: 60, max: 120 };
  let s = c.base;
  for (const e of (entries || [])) {
    if (isNum(e.delta)) s += e.delta;
  }
  if (isNum(c.min)) s = Math.max(c.min, s);
  if (isNum(c.max)) s = Math.min(c.max, s);
  return round(s, 2);
}

export function evaluateDaily(entries, cfg) {
  return { score: dailyScoreOf(entries, cfg), count: (entries || []).length };
}

export function evaluate({ studentId, fives, subjects, daily }, cfg) {
  const fRes = evaluateFives(fives, cfg.fivesWeights);
  const sRes = evaluateSubjects(subjects, cfg);
  const dRes = evaluateDaily(daily, cfg);

  const dw = cfg.dimensionWeights || { fives: 40, subject: 50, daily: 10 };
  const pairs = [
    { value: fRes.score, weight: dw.fives },
    { value: sRes.score, weight: dw.subject },
    { value: dRes.score, weight: dw.daily },
  ];
  const comp = weightedMean(pairs);

  return {
    studentId,
    fives: fRes,
    subject: sRes,
    daily: dRes,
    composite: { score: round(comp, 2) },
  };
}

export function evaluateAll(bundles, cfg) {
  return (bundles || []).map((b) => evaluate(b, cfg));
}

export const SCORE_OF = {
  composite: (ev) => ev.composite ? ev.composite.score : null,
  fives: (ev) => ev.fives ? ev.fives.score : null,
  subject: (ev) => ev.subject ? ev.subject.score : null,
  daily: (ev) => ev.daily ? ev.daily.score : null,
};

export function rankBy(results, scoreFn = SCORE_OF.composite) {
  const valid = [];
  const missing = [];
  for (const r of (results || [])) {
    const s = scoreFn(r);
    if (isNum(s)) valid.push({ item: r, score: s });
    else missing.push({ item: r, score: null });
  }

  valid.sort((a, b) => b.score - a.score);

  const ranked = [];
  const rankMap = new Map();
  let lastScore = null;
  let lastRank = 0;

  valid.forEach((row, idx) => {
    const r = (lastScore != null && Math.abs(row.score - lastScore) < 1e-6) ? lastRank : idx + 1;
    lastScore = row.score;
    lastRank = r;
    ranked.push({ ...row, rank: r });
    rankMap.set(row.item.studentId, r);
  });

  missing.forEach((row) => {
    ranked.push({ ...row, rank: null });
    rankMap.set(row.item.studentId, null);
  });

  return { ranked, rankMap };
}

export function gradeOf(score) {
  if (!isNum(score)) return { grade: '—', label: '未评定', cls: 'grade-none' };
  if (score >= 90) return { grade: 'A', label: '卓越', cls: 'grade-A' };
  if (score >= 80) return { grade: 'B', label: '良好', cls: 'grade-B' };
  if (score >= 60) return { grade: 'C', label: '合格', cls: 'grade-C' };
  return { grade: 'D', label: '待补', cls: 'grade-D' };
}

export function gradeColor(score) {
  if (!isNum(score)) return '#94a3b8';
  if (score >= 85) return '#22c55e';
  if (score >= 75) return '#6366f1';
  if (score >= 60) return '#f59e0b';
  return '#ef4444';
}
