/**
 * utils/model.js — 领域模型与出厂口径
 */

export const SCHEMA_VERSION = 1;

export const FIVES = [
  {
    key: 'de', name: '德', full: '德育', color: '#f2545b',
    desc: '品行、纪律、责任与公德',
    items: [
      { key: 'de-rule', name: '遵规守纪', hint: '校规校纪、课堂纪律' },
      { key: 'de-honest', name: '诚实守信', hint: '作业考试诚信、言行一致' },
      { key: 'de-manner', name: '文明礼貌', hint: '礼貌用语、仪容仪表、尊重他人' },
      { key: 'de-team', name: '集体责任', hint: '班级事务、值日、集体活动' },
      { key: 'de-help', name: '助人友善', hint: '帮助同学、志愿服务' },
    ],
  },
  {
    key: 'zhi', name: '智', full: '智育', color: '#3d7bfd',
    desc: '学习态度、方法与学业表现',
    items: [
      { key: 'zhi-attitude', name: '学习态度', hint: '专注度、主动性、求知欲' },
      { key: 'zhi-class', name: '课堂参与', hint: '发言、提问、讨论与合作' },
      { key: 'zhi-homework', name: '作业质量', hint: '完成度、正确率、书写规范' },
      { key: 'zhi-method', name: '学习方法', hint: '笔记、复习、错题整理' },
      { key: 'zhi-extend', name: '拓展探究', hint: '课外阅读、竞赛、研究学习' },
    ],
  },
  {
    key: 'ti', name: '体', full: '体育', color: '#16a97e',
    desc: '体质健康与运动习惯',
    items: [
      { key: 'ti-fitness', name: '体质健康', hint: '体测成绩、身体素质' },
      { key: 'ti-pe', name: '体育课表现', hint: '参与度、技能掌握、团队配合' },
      { key: 'ti-skill', name: '运动技能', hint: '专项技能、运动社团参与' },
      { key: 'ti-habit', name: '锻炼习惯', hint: '课间操、课外锻炼' },
      { key: 'ti-mind', name: '心理韧性', hint: '抗压、情绪调节、抗挫折' },
    ],
  },
  {
    key: 'mei', name: '美', full: '美育', color: '#a355e8',
    desc: '审美感受与艺术表达',
    items: [
      { key: 'mei-course', name: '艺术课程', hint: '音乐 / 美术课参与与表现' },
      { key: 'mei-taste', name: '审美表达', hint: '发现美、评价美、表达感受' },
      { key: 'mei-activity', name: '艺术活动', hint: '文艺演出、书画展览、社团' },
      { key: 'mei-create', name: '创意实践', hint: '原创作品、设计创作' },
    ],
  },
  {
    key: 'lao', name: '劳', full: '劳动教育', color: '#e08a1e',
    desc: '劳动观念、技能与习惯',
    items: [
      { key: 'lao-course', name: '劳动课程', hint: '劳动课参与与任务完成' },
      { key: 'lao-school', name: '校园劳动', hint: '值日、大扫除、绿植养护' },
      { key: 'lao-home', name: '家务劳动', hint: '家庭劳动清单完成情况' },
      { key: 'lao-practice', name: '劳动实践', hint: '社会实践、研学、志愿劳动' },
      { key: 'lao-skill', name: '劳动技能', hint: '动手能力、生活自理技能' },
    ],
  },
];

export const FIVES_KEYS = FIVES.map((f) => f.key);
export const DEFAULT_FIVES_WEIGHTS = { de: 25, zhi: 35, ti: 20, mei: 10, lao: 10 };

export const SUBJECTS = [
  { key: 'chinese', name: '语文', weight: 1.0 },
  { key: 'math', name: '数学', weight: 1.0 },
  { key: 'english', name: '英语', weight: 1.0 },
  { key: 'physics', name: '物理', weight: 0.8 },
  { key: 'chemistry', name: '化学', weight: 0.8 },
  { key: 'biology', name: '生物学', weight: 0.6 },
  { key: 'politics', name: '道德与法治', weight: 0.6 },
  { key: 'history', name: '历史', weight: 0.6 },
  { key: 'geography', name: '地理', weight: 0.6 },
  { key: 'pe', name: '体育与健康', weight: 0.5 },
  { key: 'music', name: '音乐', weight: 0.3 },
  { key: 'art', name: '美术', weight: 0.3 },
  { key: 'it', name: '信息科技', weight: 0.3 },
];

export const SUBJECT_KEYS = SUBJECTS.map((s) => s.key);
export const DEFAULT_SUBJECT_WEIGHTS = Object.fromEntries(SUBJECTS.map((s) => [s.key, s.weight]));
export const DEFAULT_TERM_WEIGHTS = { usual: 20, mid: 30, final: 50 };
export const DEFAULT_DIMENSION_WEIGHTS = { fives: 40, subject: 50, daily: 10 };

export const DIMENSIONS = [
  { key: 'fives', name: '五育并举', desc: '德智体美劳过程性评价', color: '#6366f1' },
  { key: 'subject', name: '学科成绩', desc: '13 门学科平时/期中/期末', color: '#3d7bfd' },
  { key: 'daily', name: '日常表现', desc: '校规守纪与正向加减分', color: '#22c55e' },
];

export const DEFAULT_DAILY_CONFIG = { base: 100, min: 60, max: 120 };

export const DEFAULT_DAILY_ITEMS = [
  { key: 'good-deed', label: '拾金不昧 / 好人好事', delta: +2, cat: 'pos' },
  { key: 'contest-win', label: '学科竞赛 / 艺体比赛获奖', delta: +5, cat: 'pos' },
  { key: 'class-service', label: '班级事务 / 积极服务集体', delta: +1, cat: 'pos' },
  { key: 'volunteer', label: '志愿服务 / 优秀值日', delta: +2, cat: 'pos' },
  { key: 'late', label: '迟到 / 早退', delta: -1, cat: 'neg' },
  { key: 'homework-miss', label: '缺交作业', delta: -2, cat: 'neg' },
  { key: 'discipline', label: '自习讲话 / 违纪', delta: -2, cat: 'neg' },
];

export function defaultConfig() {
  return {
    schemaVersion: SCHEMA_VERSION,
    dimensionWeights: { ...DEFAULT_DIMENSION_WEIGHTS },
    fivesWeights: { ...DEFAULT_FIVES_WEIGHTS },
    subjectWeights: { ...DEFAULT_SUBJECT_WEIGHTS },
    termWeights: { ...DEFAULT_TERM_WEIGHTS },
    daily: { ...DEFAULT_DAILY_CONFIG },
  };
}

export function emptyFives() {
  const o = {};
  for (const f of FIVES) {
    o[f.key] = {};
    for (const it of f.items) o[f.key][it.key] = null;
  }
  return o;
}

export function emptySubjects() {
  const o = {};
  for (const s of SUBJECTS) {
    o[s.key] = { usual: null, mid: null, final: null };
  }
  return o;
}
