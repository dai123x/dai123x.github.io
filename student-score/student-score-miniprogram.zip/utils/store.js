/**
 * utils/store.js — 微信小程序本地存储与状态管理中心
 */

import { defaultConfig, emptyFives, emptySubjects, SUBJECTS, FIVES, DEFAULT_DAILY_ITEMS } from './model.js';

const STORAGE_KEY = 'dx_student_score_mp_v1';
const SNAPSHOTS_KEY = 'dx_student_score_snapshots';

export const SOURCES = { TEACHER: 'teacher', SELF: 'self' };
export const SOURCE_LABEL = { teacher: '教师评分', self: '学生自评' };

const key = (studentId, source) => `${studentId}:${source}`;

class MiniStore {
  constructor() {
    this.classes = [];
    this.students = [];
    this.fives = {};
    this.subjects = {};
    this.daily = {};
    this.config = defaultConfig();
    this._listeners = new Set();
    this._hydrate();
  }

  _hydrate() {
    try {
      const raw = wx.getStorageSync(STORAGE_KEY);
      if (raw && typeof raw === 'object') {
        this.classes = Array.isArray(raw.classes) ? raw.classes : [];
        this.students = Array.isArray(raw.students) ? raw.students : [];
        this.fives = raw.fives || {};
        this.subjects = raw.subjects || {};
        this.daily = raw.daily || {};
        this.config = { ...defaultConfig(), ...(raw.config || {}) };
      }
    } catch (e) {
      console.warn('[store] 微信本地存储读取失败，初始化空数据', e);
    }

    // 若无班级，自动载入默认演示数据
    if (!this.classes.length) {
      this.loadDemo();
    }
  }

  _persist() {
    try {
      wx.setStorageSync(STORAGE_KEY, this.snapshot());
    } catch (e) {
      console.error('[store] 微信持久化落盘失败', e);
    }
    this._emit();
  }

  _emit() {
    for (const fn of this._listeners) {
      try { fn(); } catch (err) { console.error('[store] listener error', err); }
    }
  }

  subscribe(fn) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }

  snapshot() {
    return {
      classes: JSON.parse(JSON.stringify(this.classes)),
      students: JSON.parse(JSON.stringify(this.students)),
      fives: JSON.parse(JSON.stringify(this.fives)),
      subjects: JSON.parse(JSON.stringify(this.subjects)),
      daily: JSON.parse(JSON.stringify(this.daily)),
      config: JSON.parse(JSON.stringify(this.config)),
    };
  }

  restore(obj) {
    if (!obj || typeof obj !== 'object') return;
    this.classes = Array.isArray(obj.classes) ? obj.classes : [];
    this.students = Array.isArray(obj.students) ? obj.students : [];
    this.fives = obj.fives || {};
    this.subjects = obj.subjects || {};
    this.daily = obj.daily || {};
    this.config = { ...defaultConfig(), ...(obj.config || {}) };
    this._persist();
  }

  listClasses() { return this.classes.slice(); }

  getClass(id) { return this.classes.find((c) => c.id === id) || null; }

  createClass(patch) {
    const id = 'cls_' + Date.now().toString(36);
    const cls = { id, name: patch.name || '新建班级', grade: patch.grade || '八年级', term: patch.term || '2026学年第一学期', createdAt: Date.now() };
    this.classes.push(cls);
    this._persist();
    return cls;
  }

  removeClass(id) {
    this.classes = this.classes.filter((c) => c.id !== id);
    const stusToRemove = this.students.filter((s) => s.classId === id);
    this.students = this.students.filter((s) => s.classId !== id);
    stusToRemove.forEach((s) => {
      delete this.fives[key(s.id, SOURCES.TEACHER)];
      delete this.fives[key(s.id, SOURCES.SELF)];
      delete this.subjects[key(s.id, SOURCES.TEACHER)];
      delete this.subjects[key(s.id, SOURCES.SELF)];
      delete this.daily[key(s.id, SOURCES.TEACHER)];
      delete this.daily[key(s.id, SOURCES.SELF)];
    });
    this._persist();
  }

  listStudents(classId) {
    return this.students.filter((s) => s.classId === classId);
  }

  getStudent(id) { return this.students.find((s) => s.id === id) || null; }

  upsertStudent(patch) {
    let s = this.students.find((x) => x.id === patch.id);
    if (!s) {
      s = { id: patch.id || ('stu_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5)), classId: patch.classId, no: patch.no || '', name: patch.name || '', gender: patch.gender || '保密' };
      this.students.push(s);
    } else {
      Object.assign(s, patch);
    }
    this._persist();
    return s;
  }

  removeStudent(id) {
    this.students = this.students.filter((s) => s.id !== id);
    delete this.fives[key(id, SOURCES.TEACHER)];
    delete this.fives[key(id, SOURCES.SELF)];
    delete this.subjects[key(id, SOURCES.TEACHER)];
    delete this.subjects[key(id, SOURCES.SELF)];
    delete this.daily[key(id, SOURCES.TEACHER)];
    delete this.daily[key(id, SOURCES.SELF)];
    this._persist();
  }

  getFives(studentId, source = SOURCES.TEACHER) {
    const r = this.fives[key(studentId, source)];
    return r ? r.items : null;
  }

  setFives(studentId, source, items) {
    this.fives[key(studentId, source)] = { items: JSON.parse(JSON.stringify(items)), updatedAt: Date.now() };
    this._persist();
  }

  getSubjects(studentId, source = SOURCES.TEACHER) {
    const r = this.subjects[key(studentId, source)];
    return r ? r.scores : null;
  }

  setSubjects(studentId, source, scores) {
    this.subjects[key(studentId, source)] = { scores: JSON.parse(JSON.stringify(scores)), updatedAt: Date.now() };
    this._persist();
  }

  getDaily(studentId, source = SOURCES.TEACHER) {
    const r = this.daily[key(studentId, source)];
    return r ? r.entries : [];
  }

  addDailyEntry(studentId, source, entry) {
    const k = key(studentId, source);
    if (!this.daily[k]) this.daily[k] = { entries: [], updatedAt: Date.now() };
    this.daily[k].entries.unshift({ ...entry, at: Date.now() });
    this.daily[k].updatedAt = Date.now();
    this._persist();
  }

  removeDailyEntry(studentId, source, index) {
    const k = key(studentId, source);
    if (!this.daily[k] || !this.daily[k].entries) return;
    this.daily[k].entries.splice(index, 1);
    this.daily[k].updatedAt = Date.now();
    this._persist();
  }

  getConfig() { return JSON.parse(JSON.stringify(this.config)); }

  setConfig(patch) {
    this.config = { ...this.config, ...patch };
    this._persist();
  }

  // 演示数据载入
  loadDemo() {
    const cls = { id: 'cls_demo', name: '初二(3)班', grade: '八年级', term: '2026学年第一学期', createdAt: Date.now() };
    this.classes = [cls];

    const studentNames = [
      { no: '01', name: '戴璇', gender: '男' },
      { no: '02', name: '林若汐', gender: '女' },
      { no: '03', name: '陈子昂', gender: '男' },
      { no: '04', name: '苏雨桐', gender: '女' },
      { no: '05', name: '周峻熙', gender: '男' },
      { no: '06', name: '夏梦瑶', gender: '女' },
      { no: '07', name: '王嘉尔', gender: '男' },
      { no: '08', name: '许知远', gender: '男' },
      { no: '09', name: '沈清歌', gender: '女' },
      { no: '10', name: '赵梓涵', gender: '女' },
      { no: '11', name: '孙博文', gender: '男' },
      { no: '12', name: '李思源', gender: '男' }
    ];

    this.students = studentNames.map((s, idx) => ({
      id: 'stu_' + (idx + 1),
      classId: cls.id,
      no: s.no,
      name: s.name,
      gender: s.gender,
    }));

    this.fives = {};
    this.subjects = {};
    this.daily = {};

    // 预填评分数据
    this.students.forEach((stu, sIdx) => {
      // 五育
      const fItem = emptyFives();
      const baseScore = 80 + ((sIdx * 7) % 18);
      for (const f of FIVES) {
        for (const it of f.items) {
          fItem[f.key][it.key] = Math.min(100, Math.max(65, baseScore + ((it.key.charCodeAt(0) * 3) % 15) - 6));
        }
      }
      this.fives[key(stu.id, SOURCES.TEACHER)] = { items: fItem, updatedAt: Date.now() };

      // 学科
      const sItem = emptySubjects();
      for (const s of SUBJECTS) {
        const u = Math.min(100, Math.max(55, baseScore + ((s.key.charCodeAt(0) * 2) % 16) - 5));
        const m = Math.min(100, Math.max(55, u + ((sIdx % 3) - 1) * 3));
        const fin = Math.min(100, Math.max(55, m + ((sIdx % 2) === 0 ? 4 : -2)));
        sItem[s.key] = { usual: u, mid: m, final: fin };
      }
      this.subjects[key(stu.id, SOURCES.TEACHER)] = { scores: sItem, updatedAt: Date.now() };

      // 日常表现流水
      const dEntries = [];
      if (sIdx % 2 === 0) dEntries.push({ key: 'good-deed', label: '拾金不昧 / 好人好事', delta: +2, at: Date.now() });
      if (sIdx % 3 === 0) dEntries.push({ key: 'class-service', label: '积极服务班级集体', delta: +1, at: Date.now() });
      if (sIdx === 0) dEntries.push({ key: 'contest-win', label: '全国数理竞赛省一等奖', delta: +5, at: Date.now() });
      this.daily[key(stu.id, SOURCES.TEACHER)] = { entries: dEntries, updatedAt: Date.now() };
    });

    this._persist();
  }

  // 快照管理
  createSnapshot(name) {
    let list = [];
    try { list = wx.getStorageSync(SNAPSHOTS_KEY) || []; } catch (e) { list = []; }
    const snap = {
      id: 'snap_' + Date.now(),
      time: new Date().toLocaleString(),
      name: name || ('快照存档 (' + this.students.length + '人)'),
      data: this.snapshot()
    };
    list.unshift(snap);
    if (list.length > 8) list.pop();
    wx.setStorageSync(SNAPSHOTS_KEY, list);
    return snap;
  }

  listSnapshots() {
    try { return wx.getStorageSync(SNAPSHOTS_KEY) || []; } catch (e) { return []; }
  }

  restoreSnapshot(snapId) {
    const list = this.listSnapshots();
    const snap = list.find((s) => s.id === snapId);
    if (snap && snap.data) {
      this.restore(snap.data);
      return true;
    }
    return false;
  }

  deleteSnapshot(snapId) {
    let list = this.listSnapshots();
    list = list.filter((s) => s.id !== snapId);
    wx.setStorageSync(SNAPSHOTS_KEY, list);
  }
}

export const store = new MiniStore();
